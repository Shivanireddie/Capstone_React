import React from "react";
const Payment=()=>{
    return(
        <div>
            <h1>heloo</h1>
        </div>

    )

}
export default Payment